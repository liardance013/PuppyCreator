# PuppyCreator 3.0
Android WebView application, min Android 8.0. Open in Android Studio or use the GitHub Actions workflow to build a debug APK.

Features: writing editor, drawing timer, art gallery, stats, puppy playground, offline praise, 3 reminders per day by default, notification scheduling, local JSON import/export, WebDAV experimental backup, manual share-to-Baidu-Netdisk/Quark-Netdisk backup.

**Important limitations**:
- Baidu Netdisk and Quark Netdisk: use Android system share sheet. Select the installed cloud app and complete upload there. Not direct OAuth, not automatic sync. Restore by downloading JSON and importing in app.
- Android reminders use AlarmManager.setAndAllowWhileIdle (inexact), subject to Android battery policies; notifications require permission. Reminders are rescheduled after reboot.
- This project has not been compiled or installed in a real Android device in this environment. Test before relying on backups or reminders.
- API credentials stored in local WebView storage; do not use sensitive production credentials without stronger protection.
- Backups are unencrypted JSON; treat them as private.
