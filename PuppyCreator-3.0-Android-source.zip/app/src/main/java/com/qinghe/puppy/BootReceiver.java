package com.qinghe.puppy;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {public void onReceive(Context c,Intent i){Scheduler.schedule(c);}}
