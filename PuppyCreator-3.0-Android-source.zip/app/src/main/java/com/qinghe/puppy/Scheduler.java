package com.qinghe.puppy;
import android.app.*;import android.content.*;import android.os.Build;import org.json.JSONObject;import java.util.Calendar;
public class Scheduler {
 public static void schedule(Context c){
  AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  try{
   JSONObject d=new JSONObject(c.getSharedPreferences("puppy",0).getString("state","{}"));
   JSONObject r=d.optJSONObject("reminders");
   if(r==null || !r.optBoolean("enabled",false)){cancel(c);return;}
   String[] st=r.optString("time","09:00").split(":");String[] et=r.optString("end","22:00").split(":");
   int start=Integer.parseInt(st[0])*60+Integer.parseInt(st[1]),end=Integer.parseInt(et[0])*60+Integer.parseInt(et[1]);
   int gap=Math.max(5,r.optInt("interval",60)),max=Math.min(30,Math.max(1,r.optInt("max",3)));
   for(int i=0;i<30;i++){
    Intent in=new Intent(c,ReminderReceiver.class);in.putExtra("index",i);
    PendingIntent pi=PendingIntent.getBroadcast(c,4000+i,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    a.cancel(pi);
    if(i>=max||start+i*gap>end)continue;
    Calendar t=Calendar.getInstance();t.set(Calendar.HOUR_OF_DAY,(start+i*gap)/60);t.set(Calendar.MINUTE,(start+i*gap)%60);t.set(Calendar.SECOND,0);t.set(Calendar.MILLISECOND,0);
    if(t.getTimeInMillis()<=System.currentTimeMillis())t.add(Calendar.DAY_OF_YEAR,1);
    a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),pi);
   }
  }catch(Exception ignored){}
 }
 static void cancel(Context c){AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);for(int i=0;i<30;i++){PendingIntent p=PendingIntent.getBroadcast(c,4000+i,new Intent(c,ReminderReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);a.cancel(p);}}
}