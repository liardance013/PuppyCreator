package com.qinghe.puppy;
import android.app.*;
import android.os.*;
import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.webkit.*;
import android.net.Uri;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1);
  web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(true);
  web.setWebViewClient(new WebViewClient());
  web.setWebChromeClient(new WebChromeClient());
  web.addJavascriptInterface(new Bridge(),"PuppyNative");
  setContentView(web);
  web.loadUrl("file:///android_asset/index.html");
  ReminderReceiver.createChannel(this);
  Scheduler.schedule(this);
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 public class Bridge {
  @JavascriptInterface public void syncState(String json){
   String old=getSharedPreferences("puppy",0).getString("state","");
   getSharedPreferences("puppy",0).edit().putString("state",json).apply();
   try{org.json.JSONObject a=new org.json.JSONObject(old.isEmpty()?"{}":old),b=new org.json.JSONObject(json);
    String x=a.optJSONObject("reminders")==null?"":a.optJSONObject("reminders").toString(),y=b.optJSONObject("reminders")==null?"":b.optJSONObject("reminders").toString();
    if(!x.equals(y))Scheduler.schedule(MainActivity.this);
   }catch(Exception ignored){}
  }
  @JavascriptInterface public void shareBackup(String json,String filename,String provider){
   try{
    File dir=new File(getCacheDir(),"backups");dir.mkdirs();
    File file=new File(dir,"PuppyCreator-backup.json");
    try(FileOutputStream f=new FileOutputStream(file)){f.write(json.getBytes(StandardCharsets.UTF_8));}
    Uri uri=androidxFileUri(file);
    Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/json");
    send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    runOnUiThread(()->startActivity(Intent.createChooser(send,"分享到百度网盘 / 夸克网盘")));
   }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"分享失败："+e.getMessage(),Toast.LENGTH_LONG).show());}
  }
  private Uri androidxFileUri(File f){return Uri.parse("content://"+getPackageName()+".backup/"+f.getName());}
 }
}