package com.qinghe.puppy;
import android.content.*;import android.database.Cursor;import android.database.MatrixCursor;import android.net.Uri;import android.os.ParcelFileDescriptor;import android.provider.OpenableColumns;import java.io.*;
public class BackupProvider extends ContentProvider {
 public boolean onCreate(){return true;}
 public String getType(Uri uri){return "application/json";}
 public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
  MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});
  File f=new File(getContext().getCacheDir(),"backups/PuppyCreator-backup.json");
  c.addRow(new Object[]{"PuppyCreator-backup.json",f.length()});return c;
 }
 public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{
  return ParcelFileDescriptor.open(new File(getContext().getCacheDir(),"backups/PuppyCreator-backup.json"),ParcelFileDescriptor.MODE_READ_ONLY);
 }
 public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
 public int delete(Uri u,String s,String[] a){return 0;}
 public int update(Uri u,ContentValues v,String s,String[] a){return 0;}
}
