package com.qinghe.puppy;
import android.app.*;import android.content.*;import android.os.Build;import org.json.JSONObject;import java.text.SimpleDateFormat;import java.util.Date;import java.util.Locale;
public class ReminderReceiver extends BroadcastReceiver {
 public static void createChannel(Context c){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("creative","创作提醒",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("每日创作打卡提醒");((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);}}
 @Override public void onReceive(Context c,Intent intent){
  try{
   JSONObject d=new JSONObject(c.getSharedPreferences("puppy",0).getString("state","{}"));
   JSONObject r=d.optJSONObject("reminders");if(r==null||!r.optBoolean("enabled",false)){Scheduler.schedule(c);return;}
   String day=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
   if((r.optBoolean("paused",false)&&day.equals(r.optString("day","")))){Scheduler.schedule(c);return;}
   JSONObject w=d.optJSONObject("writing");String words=w==null?"":w.optString(day,"");
   int count=words.codePointCount(0,words.length()),goalW=d.optJSONObject("goals")==null?500:d.optJSONObject("goals").optInt("writing",500);
   int minutes=0;org.json.JSONArray drawing=d.optJSONArray("drawing");
   if(drawing!=null)for(int i=0;i<drawing.length();i++){JSONObject e=drawing.optJSONObject(i);if(e!=null&&day.equals(e.optString("day")))minutes+=e.optInt("minutes",0);}
   int goalD=d.optJSONObject("goals")==null?60:d.optJSONObject("goals").optInt("drawing",60);
   if(count<goalW||minutes<goalD){
    createChannel(c);
    Intent open=new Intent(c,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification.Builder b=new Notification.Builder(c,"creative").setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("金毛来夸夸咪啦").setContentText("今天写作 "+count+"/"+goalW+" 字，绘画 "+minutes+"/"+goalD+" 分钟。来看看今天的进度吧！").setContentIntent(pi).setAutoCancel(true);
    ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(200+intent.getIntExtra("index",0),b.build());
   }
  }catch(Exception ignored){}
  Scheduler.schedule(c);
 }
}