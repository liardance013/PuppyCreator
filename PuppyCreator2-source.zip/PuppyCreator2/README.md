# 小狗创作助手 2.0（Android 原生 Java）

## 已实现
- 手账色系五页布局；每日快速打卡；文章编辑与本地保存；绘画计时与系统相册图片引用；7天汇总及30天记录。
- Android 本地提醒（默认设备当地时间 09:00）、重启后重排、测试通知。
- 多模型 OpenAI Chat Completions 兼容接口（手动配置 HTTPS endpoint、模型名及 API Key）。密钥使用 Android Keystore AES-GCM 加密保存。
- JSON 文件导出/导入、WebDAV 手动备份上传/恢复（HTTPS + Basic Auth）。

## 重要限制
- **此项目已生成源码，尚未在当前环境完成 Android SDK 编译或真机测试。** GitHub Actions 的首次构建可能暴露编译错误。
- AI 目前是**用户主动发送消息**，定时通知使用本地预设文案，不会在后台调用模型；云端 AI 定时推送需另外开发后端、调度和 FCM。
- WebDAV 是**手动备份/恢复**，不是双向自动实时同步；远端文件由用户指定，恢复会覆盖本地数据。
- 作品图片只保存本机持久化 URI 引用，不上传原图，跨设备备份无法恢复原始图片。
- 计时器只在应用进程存活时计时；离开页面后仍能计时，但进程被系统杀死会丢失当次未保存时长。
- API 兼容范围为 `POST /chat/completions` JSON 请求响应结构；并非所有模型服务都兼容。
- 本地提醒受 Android 通知权限、精确闹钟权限、厂商省电策略影响。

## 旧版数据迁移
- 沿用 v1 `applicationId = com.qinghe.puppy`、签名兼容且版本号升至 2，直接覆盖安装后会读取旧版 `SharedPreferences("prefs")` 中的 `records`，保留原有打卡。
- **注意：GitHub Actions debug APK 的签名不保证跨运行环境/项目稳定。** 如 Android 提示签名不匹配，先在旧版设置之外自行备份原有数据；v1 没有内置导出，因此**不要直接卸载旧版**，否则可能永久丢失打卡记录。建议先测试升级能否直接安装。
- 不要把 API 密钥、WebDAV 密码提交到 GitHub 仓库。

## 通过 GitHub Actions 构建
- 上传根目录文件 `PuppyCreator2-source.zip` 到现有仓库。
- 用附带的 `.github/workflows/build.yml` 替换现有同名工作流文件（或者将其内容复制进去）。
- 在 Actions 手动执行，成功后下载 `PuppyCreator-v2-APK` artifact。
- 源码 ZIP 内层目录是 `PuppyCreator2/`。

## 额外服务
- AI：需自备兼容 OpenAI Chat Completions 的 HTTPS API 及额度；不等于 ChatGPT Plus 订阅。
- WebDAV：需用户自有支持 WebDAV 的云存储、HTTPS 文件地址、用户名及应用密码。
- 真正的云端定时 AI 推送：需后端（如 Supabase Edge Functions/自有服务器）、安全密钥存储、定时调度、Firebase Cloud Messaging 与用户认证；本版未配置。
