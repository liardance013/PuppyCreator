package com.qinghe.puppy;
import android.app.*;
import android.content.*;
import android.os.Build;
import java.util.Calendar;

public class Scheduler {
    public static void schedule(Context c) {
        android.content.SharedPreferences p=c.getSharedPreferences("prefs",0);
        int hour=p.getInt("hour",9), minute=p.getInt("minute",0);
        Calendar t=Calendar.getInstance();t.set(Calendar.HOUR_OF_DAY,hour);t.set(Calendar.MINUTE,minute);t.set(Calendar.SECOND,0);t.set(Calendar.MILLISECOND,0);
        if(t.getTimeInMillis()<=System.currentTimeMillis())t.add(Calendar.DAY_OF_YEAR,1);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi=PendingIntent.getBroadcast(c,100,new Intent(c,ReminderReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),pi);
        else if(Build.VERSION.SDK_INT<31)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),pi);
    }
}
