package com.qinghe.puppy;
import android.content.*;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){Scheduler.schedule(c);} }
