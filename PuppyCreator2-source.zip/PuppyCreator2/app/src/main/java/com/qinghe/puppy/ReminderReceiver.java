package com.qinghe.puppy;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends android.content.BroadcastReceiver {
    public static final String CHANNEL="daily_creativity";
    @Override public void onReceive(Context context, Intent intent) {
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"每日创作督促",NotificationManager.IMPORTANCE_HIGH));
        Intent open=new Intent(context,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(context,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("小狗来督促啦！")
            .setContentText("今天写100字、画15分钟。完成后记得回来打卡！")
            .setStyle(new Notification.BigTextStyle().bigText("清和，今天写作至少100字、绘画至少15分钟。先开始，再追求完美。完成后记得回来打卡！"))
            .setContentIntent(pi).setAutoCancel(true).build();
        try { nm.notify(100,n); } catch(SecurityException ignored) {}
        Scheduler.schedule(context);
    }
}
