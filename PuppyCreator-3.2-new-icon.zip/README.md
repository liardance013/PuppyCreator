# PuppyCreator 3.2
Android WebView application, min Android 8.0. Open in Android Studio or use the GitHub Actions workflow to build a debug APK.

Features: writing editor, drawing timer, art gallery, stats, puppy playground, offline praise, 3 reminders per day by default, notification scheduling, local JSON import/export, WebDAV experimental backup, manual share-to-Baidu-Netdisk/Quark-Netdisk backup.

**Important limitations**:
- Baidu Netdisk and Quark Netdisk: use Android system share sheet. Select the installed cloud app and complete upload there. Not direct OAuth, not automatic sync. Restore by downloading JSON and importing in app.
- Android reminders use AlarmManager exact alarms when the 'Alarms & reminders' permission is granted (falls back to inexact otherwise); notifications require permission. Reminders are rescheduled after reboot, app update, and time/timezone change. On Xiaomi/Huawei/OPPO/vivo devices also allow auto-start and disable battery optimization.
- This project has not been compiled or installed in a real Android device in this environment. Test before relying on backups or reminders.
- API credentials stored in local WebView storage; do not use sensitive production credentials without stronger protection.
- Backups are unencrypted JSON; treat them as private.

Version 3.1: launcher icons from user-provided golden puppy illustration, adaptive icon and notification paw icon.

Version 3.2 fixes:
- Reminders: exact alarms + permission buttons (notification / exact alarm / battery), snooze honoured natively, state synced to native on startup, test notification uses native API.
- Import/export: WebView file chooser implemented (import backup, upload artwork); exports go through the system 'save file' dialog.
- Cloud backup: cloudBackup() was missing; now shares to Baidu/Quark directly when installed, otherwise opens the share sheet. Backup provider no longer exported; API key is stripped from backups.
- WebDAV / AI chat: requests go through native HTTPS, so no CORS failures.
- Data (incl. artwork) now stored in a native file (filesDir/state.json), no WebView localStorage quota; existing localStorage data migrates automatically on first launch.
- Also: Android 15 edge-to-edge insets, rotation no longer reloads the page, JS dialogs, external links blocked inside WebView, debounced autosave, timer survives restarts.
