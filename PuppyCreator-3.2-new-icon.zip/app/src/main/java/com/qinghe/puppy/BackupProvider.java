package com.qinghe.puppy;
import android.content.*;import android.database.Cursor;import android.database.MatrixCursor;import android.net.Uri;import android.os.ParcelFileDescriptor;import android.provider.OpenableColumns;import java.io.*;
public class BackupProvider extends ContentProvider {
 public boolean onCreate(){return true;}
 private File fileFor(Uri uri)throws FileNotFoundException{
  String name=uri.getLastPathSegment();
  if(name==null||name.contains("/")||name.contains("\\")||name.contains(".."))throw new FileNotFoundException("bad name");
  File f=new File(new File(getContext().getCacheDir(),"backups"),name);
  if(!f.exists())throw new FileNotFoundException(name);
  return f;
 }
 public String getType(Uri uri){return "application/json";}
 public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
  MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});
  try{File f=fileFor(uri);c.addRow(new Object[]{f.getName(),f.length()});}catch(FileNotFoundException ignored){}
  return c;
 }
 public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{
  return ParcelFileDescriptor.open(fileFor(uri),ParcelFileDescriptor.MODE_READ_ONLY);
 }
 public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
 public int delete(Uri u,String s,String[] a){return 0;}
 public int update(Uri u,ContentValues v,String s,String[] a){return 0;}
}
