package com.qinghe.puppy;
import android.app.*;import android.content.*;import android.os.Build;import org.json.JSONArray;import org.json.JSONObject;import java.text.SimpleDateFormat;import java.util.Date;import java.util.Locale;
public class ReminderReceiver extends BroadcastReceiver {
 public static void createChannel(Context c){
  if(Build.VERSION.SDK_INT>=26){
   NotificationChannel ch=new NotificationChannel("creative","创作提醒",NotificationManager.IMPORTANCE_HIGH);
   ch.setDescription("每日创作打卡提醒");
   ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
  }
 }
 static String progressText(JSONObject d,String day,int[] out){
  JSONObject w=d.optJSONObject("writing");String words=w==null?"":w.optString(day,"");
  int count=words.codePointCount(0,words.length());
  JSONObject goals=d.optJSONObject("goals");
  int goalW=goals==null?500:goals.optInt("writing",500),goalD=goals==null?60:goals.optInt("drawing",60);
  int minutes=0;JSONArray drawing=d.optJSONArray("drawing");
  if(drawing!=null)for(int i=0;i<drawing.length();i++){JSONObject e=drawing.optJSONObject(i);if(e!=null&&day.equals(e.optString("day")))minutes+=e.optInt("minutes",0);}
  out[0]=count;out[1]=goalW;out[2]=minutes;out[3]=goalD;
  return "今天写作 "+count+"/"+goalW+" 字，绘画 "+minutes+"/"+goalD+" 分钟。来看看今天的进度吧！";
 }
 static void post(Context c,int id,String title,String text){
  createChannel(c);
  Intent open=new Intent(c,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
  PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=new Notification.Builder(c,"creative").setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setContentIntent(pi).setAutoCancel(true);
  try{((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id,b.build());}catch(Exception ignored){}
 }
 @Override public void onReceive(Context c,Intent intent){
  try{
   JSONObject d=new JSONObject(c.getSharedPreferences("puppy",0).getString("state","{}"));
   JSONObject r=d.optJSONObject("reminders");
   if(r!=null&&r.optBoolean("enabled",false)){
    String day=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
    boolean paused=r.optBoolean("paused",false)&&day.equals(r.optString("day",""));
    boolean snoozed=r.optLong("snoozeUntil",0)>System.currentTimeMillis()+1000;
    if(!paused&&!snoozed){
     int[] p=new int[4];String text=progressText(d,day,p);
     if(p[0]<p[1]||p[2]<p[3])post(c,200+intent.getIntExtra("index",0),"金毛来夸夸咪啦",text);
    }
   }
  }catch(Exception ignored){}
  Scheduler.schedule(c);
 }
}
