package com.qinghe.puppy;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** Stores the slim state the native side needs (reminders, goals, today's progress) and reschedules alarms when reminder settings change. */
class SharedPrefsHelper {
 static void apply(Context c,String json){
  SharedPreferences sp=c.getSharedPreferences("puppy",0);
  String old=sp.getString("state","");
  sp.edit().putString("state",json).apply();
  String x="",y="";
  try{JSONObject a=new JSONObject(old.isEmpty()?"{}":old);JSONObject r=a.optJSONObject("reminders");x=r==null?"":r.toString();}catch(Exception ignored){}
  try{JSONObject b=new JSONObject(json);JSONObject r=b.optJSONObject("reminders");y=r==null?"":r.toString();}catch(Exception ignored){}
  if(!x.equals(y))Scheduler.schedule(c);
 }
}
