package com.qinghe.puppy;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
 static final int REQ_NOTIF=1,REQ_FILE=2,REQ_SAVE=3;
 static final int BG=0xFFF8F5F2;
 WebView web;
 ValueCallback<Uri[]> fileCallback;
 byte[] pendingSave;

 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
   requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);
  setupSystemBars();
  web=new WebView(this);
  WebSettings s=web.getSettings();
  s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);
  web.setBackgroundColor(BG);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){
    Uri u=req.getUrl();
    if(u!=null&&u.toString().startsWith("file:///android_asset/"))return false;
    try{if(u!=null)startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
    return true;
   }
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams p){
    if(fileCallback!=null){fileCallback.onReceiveValue(null);fileCallback=null;}
    fileCallback=cb;
    Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.addCategory(Intent.CATEGORY_OPENABLE);
    String[] types=p.getAcceptTypes();
    boolean img=types!=null&&types.length>0&&types[0]!=null&&types[0].startsWith("image");
    i.setType(img?"image/*":"*/*");
    if(p.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE)i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
    try{startActivityForResult(Intent.createChooser(i,"选择文件"),REQ_FILE);}
    catch(Exception e){fileCallback=null;cb.onReceiveValue(null);toast("无法打开文件选择器");}
    return true;
   }
   @Override public boolean onJsAlert(WebView v,String url,String msg,final JsResult r){
    if(isFinishing()){r.cancel();return true;}
    new AlertDialog.Builder(MainActivity.this).setMessage(msg).setPositiveButton("好",(d,w)->r.confirm()).setOnCancelListener(d->r.cancel()).show();
    return true;
   }
   @Override public boolean onJsConfirm(WebView v,String url,String msg,final JsResult r){
    if(isFinishing()){r.cancel();return true;}
    new AlertDialog.Builder(MainActivity.this).setMessage(msg).setPositiveButton("确定",(d,w)->r.confirm()).setNegativeButton("取消",(d,w)->r.cancel()).setOnCancelListener(d->r.cancel()).show();
    return true;
   }
  });
  web.addJavascriptInterface(new Bridge(),"PuppyNative");
  FrameLayout root=new FrameLayout(this);
  root.setBackgroundColor(BG);
  root.addView(web,new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.MATCH_PARENT));
  root.setOnApplyWindowInsetsListener((v,ins)->{
   int l,t,r,bt;
   if(Build.VERSION.SDK_INT>=30){
    android.graphics.Insets i=ins.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.ime()|WindowInsets.Type.displayCutout());
    l=i.left;t=i.top;r=i.right;bt=i.bottom;
    v.setPadding(l,t,r,bt);
    return WindowInsets.CONSUMED;
   }
   l=ins.getSystemWindowInsetLeft();t=ins.getSystemWindowInsetTop();r=ins.getSystemWindowInsetRight();bt=ins.getSystemWindowInsetBottom();
   v.setPadding(l,t,r,bt);
   return ins.consumeSystemWindowInsets();
  });
  setContentView(root);
  root.requestApplyInsets();
  web.loadUrl("file:///android_asset/index.html");
  ReminderReceiver.createChannel(this);
  Scheduler.schedule(this);
 }

 @SuppressWarnings("deprecation")
 void setupSystemBars(){
  try{
   getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
   if(Build.VERSION.SDK_INT>=26){
    View dv=getWindow().getDecorView();
    dv.setSystemUiVisibility(dv.getSystemUiVisibility()|View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
   }
  }catch(Exception ignored){}
 }

 void toast(String s){runOnUiThread(()->Toast.makeText(MainActivity.this,s,Toast.LENGTH_LONG).show());}

 @Override protected void onResume(){
  super.onResume();
  Scheduler.schedule(this);
  if(web!=null)web.evaluateJavascript("window.refreshNativeStatus&&refreshNativeStatus()",null);
 }

 @Override public void onRequestPermissionsResult(int code,String[] perms,int[] res){
  super.onRequestPermissionsResult(code,perms,res);
  ReminderReceiver.createChannel(this);
  Scheduler.schedule(this);
  if(web!=null)web.evaluateJavascript("window.refreshNativeStatus&&refreshNativeStatus()",null);
 }

 @Override protected void onActivityResult(int req,int res,Intent data){
  super.onActivityResult(req,res,data);
  if(req==REQ_FILE){
   if(fileCallback!=null){
    Uri[] r=null;
    if(res==RESULT_OK)r=WebChromeClient.FileChooserParams.parseResult(res,data);
    fileCallback.onReceiveValue(r);fileCallback=null;
   }
   return;
  }
  if(req==REQ_SAVE){
   byte[] bytes=pendingSave;pendingSave=null;
   if(res==RESULT_OK&&data!=null&&data.getData()!=null&&bytes!=null){
    try(OutputStream os=getContentResolver().openOutputStream(data.getData(),"wt")){
     if(os==null)throw new IOException("无法写入所选位置");
     os.write(bytes);os.flush();
     toast("已保存到所选位置");
    }catch(Exception e){toast("保存失败："+e.getMessage());}
   }
  }
 }

 @Override public void onBackPressed(){
  web.evaluateJavascript("(function(){var a=document.querySelector('.page.active');if(a&&a.id!=='home'){go('home');return 'handled'}return 'exit'})()",v->{
   if(v==null||!v.contains("handled"))MainActivity.super.onBackPressed();
  });
 }

 public class Bridge {
  @JavascriptInterface public void syncState(String json){
   try{
    SharedPrefsHelper.apply(MainActivity.this,json);
   }catch(Exception ignored){}
  }

  @JavascriptInterface public String loadState(){
   File f=new File(getFilesDir(),"state.json");
   if(!f.exists())return "";
   try(InputStream in=new FileInputStream(f)){
    ByteArrayOutputStream bo=new ByteArrayOutputStream();
    byte[] buf=new byte[16384];int n;
    while((n=in.read(buf))>0)bo.write(buf,0,n);
    return new String(bo.toByteArray(),StandardCharsets.UTF_8);
   }catch(Exception e){return "";}
  }

  @JavascriptInterface public boolean saveState(String json){
   try{
    File f=new File(getFilesDir(),"state.json"),t=new File(getFilesDir(),"state.json.tmp");
    try(FileOutputStream o=new FileOutputStream(t)){o.write(json.getBytes(StandardCharsets.UTF_8));o.getFD().sync();}
    Files.move(t.toPath(),f.toPath(),StandardCopyOption.REPLACE_EXISTING);
    return true;
   }catch(Exception e){return false;}
  }

  @JavascriptInterface public String getStatus(){
   try{
    JSONObject o=new JSONObject();
    NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
    o.put("notif",nm.areNotificationsEnabled());
    o.put("exact",Scheduler.canExact(MainActivity.this));
    PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);
    o.put("battery",pm.isIgnoringBatteryOptimizations(getPackageName()));
    return o.toString();
   }catch(Exception e){return "{}";}
  }

  @JavascriptInterface public void requestNotificationPermission(){
   runOnUiThread(()->{
    NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
    if(nm.areNotificationsEnabled()){toast("通知权限已开启");return;}
    if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED
      &&shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)){
     requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);return;
    }
    openNotificationSettingsInternal();
   });
  }

  @JavascriptInterface public void openNotificationSettings(){runOnUiThread(()->openNotificationSettingsInternal());}

  @JavascriptInterface public void requestExactAlarm(){
   runOnUiThread(()->{
    if(Scheduler.canExact(MainActivity.this)){toast("精确闹钟权限已开启");return;}
    try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}
    catch(Exception e){toast("请在系统设置中为本应用开启「闹钟和提醒」");}
   });
  }

  @JavascriptInterface public void openBatterySettings(){
   runOnUiThread(()->{
    try{
     PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);
     if(!pm.isIgnoringBatteryOptimizations(getPackageName())){
      startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName())));
     }else{
      toast("已允许后台运行。若仍收不到提醒，请在系统设置中允许本应用「自启动」并关闭省电限制");
      startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));
     }
    }catch(Exception e){
     try{startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}catch(Exception e2){toast("请在系统设置中手动关闭本应用的省电限制");}
    }
   });
  }

  @JavascriptInterface public String testNotification(){
   NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
   if(!nm.areNotificationsEnabled()){
    runOnUiThread(()->{
     if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED
       &&shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS))
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);
     else openNotificationSettingsInternal();
    });
    return "denied";
   }
   String text="这是一条测试通知。";
   try{
    JSONObject d=new JSONObject(getSharedPreferences("puppy",0).getString("state","{}"));
    String day=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
    text=ReminderReceiver.progressText(d,day,new int[4]);
   }catch(Exception ignored){}
   ReminderReceiver.post(MainActivity.this,199,"金毛来夸夸咪啦（测试）",text);
   return "ok";
  }

  @JavascriptInterface public String shareBackup(String json,String filename,String provider){
   try{
    String name=sanitizeName(filename);
    File dir=new File(getCacheDir(),"backups");dir.mkdirs();
    File[] old=dir.listFiles();if(old!=null)for(File o:old)o.delete();
    File file=new File(dir,name);
    try(FileOutputStream f=new FileOutputStream(file)){f.write(json.getBytes(StandardCharsets.UTF_8));}
    final Uri uri=Uri.parse("content://"+getPackageName()+".backup/"+Uri.encode(name));
    final Intent send=new Intent(Intent.ACTION_SEND);
    send.setType("application/json");
    send.putExtra(Intent.EXTRA_STREAM,uri);
    send.putExtra(Intent.EXTRA_SUBJECT,name);
    send.setClipData(ClipData.newRawUri(name,uri));
    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    ResolveInfo target=findTarget(send,provider);
    if(target!=null){
     final Intent direct=new Intent(send);
     direct.setClassName(target.activityInfo.packageName,target.activityInfo.name);
     grantUriPermission(target.activityInfo.packageName,uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
     runOnUiThread(()->{
      try{startActivity(direct);}
      catch(Exception e){startActivity(Intent.createChooser(send,"分享备份文件"));}
     });
     return "direct";
    }
    runOnUiThread(()->startActivity(Intent.createChooser(send,"分享到百度网盘 / 夸克网盘")));
    return "chooser";
   }catch(Exception e){
    toast("分享失败："+e.getMessage());
    return "error";
   }
  }

  @JavascriptInterface public void saveFile(String filename,String content,String mime){
   pendingSave=content.getBytes(StandardCharsets.UTF_8);
   final String name=sanitizeName(filename);
   final String type=(mime==null||mime.isEmpty())?"application/octet-stream":mime;
   runOnUiThread(()->{
    try{
     Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
     i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(type);i.putExtra(Intent.EXTRA_TITLE,name);
     startActivityForResult(i,REQ_SAVE);
    }catch(Exception e){pendingSave=null;toast("无法打开保存位置选择器："+e.getMessage());}
   });
  }

  @JavascriptInterface public void http(final String id,final String method,final String url,final String headersJson,final String body){
   new Thread(()->{
    JSONObject res=new JSONObject();
    try{
     URL u=new URL(url);
     if(!"https".equalsIgnoreCase(u.getProtocol()))throw new IOException("仅支持 HTTPS 地址");
     HttpURLConnection h=(HttpURLConnection)u.openConnection();
     h.setConnectTimeout(20000);h.setReadTimeout(90000);h.setRequestMethod(method);
     if(headersJson!=null&&!headersJson.isEmpty()){
      JSONObject hj=new JSONObject(headersJson);
      Iterator<String> it=hj.keys();
      while(it.hasNext()){String k=it.next();h.setRequestProperty(k,hj.getString(k));}
     }
     if(body!=null&&!body.isEmpty()&&!"GET".equals(method)){
      byte[] bs=body.getBytes(StandardCharsets.UTF_8);
      h.setDoOutput(true);h.setFixedLengthStreamingMode(bs.length);
      try(OutputStream os=h.getOutputStream()){os.write(bs);}
     }
     int code=h.getResponseCode();
     InputStream is=code>=400?h.getErrorStream():h.getInputStream();
     String text="";
     if(is!=null){
      try(InputStream in=is){
       ByteArrayOutputStream bo=new ByteArrayOutputStream();
       byte[] buf=new byte[8192];int n;
       while((n=in.read(buf))>0)bo.write(buf,0,n);
       text=new String(bo.toByteArray(),StandardCharsets.UTF_8);
      }
     }
     res.put("status",code);res.put("body",text);
    }catch(Exception e){
     try{res.put("error",String.valueOf(e.getMessage()));}catch(Exception ignored){}
    }
    final String js="window.__nativeHttpDone("+JSONObject.quote(id)+","+res.toString()+")";
    runOnUiThread(()->web.evaluateJavascript(js,null));
   }).start();
  }
 }

 void openNotificationSettingsInternal(){
  try{
   Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());
   startActivity(i);
  }catch(Exception e){
   try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}
   catch(Exception e2){toast("请在系统设置中为本应用开启通知");}
  }
 }

 static String sanitizeName(String n){
  if(n==null||n.trim().isEmpty())n="PuppyCreator-backup.json";
  n=n.replaceAll("[\\\\/:*?\"<>|\\s]+","_");
  if(n.length()>80)n=n.substring(n.length()-80);
  return n;
 }

 ResolveInfo findTarget(Intent send,String provider){
  if(provider==null)return null;
  try{
   PackageManager pm=getPackageManager();
   List<ResolveInfo> list=pm.queryIntentActivities(send,0);
   for(ResolveInfo ri:list){
    String pkg=ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
    String label=String.valueOf(ri.loadLabel(pm));
    if("baidu".equals(provider)&&(pkg.contains("baidu.netdisk")||label.contains("百度网盘")))return ri;
    if("quark".equals(provider)&&(pkg.contains("quark")||label.contains("夸克")))return ri;
   }
  }catch(Exception ignored){}
  return null;
 }
}
