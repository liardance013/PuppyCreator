package com.qinghe.puppy;
import android.app.*;import android.content.*;import android.os.Build;import org.json.JSONObject;import java.util.Calendar;
public class Scheduler {
 static final int BASE=4000,SNOOZE_ID=3999;
 static boolean canExact(Context c){
  if(Build.VERSION.SDK_INT<31)return true;
  AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  return a.canScheduleExactAlarms();
 }
 private static void set(Context c,AlarmManager a,long at,PendingIntent pi){
  try{
   if(canExact(c))a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
   else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
  }catch(SecurityException e){
   a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
  }
 }
 private static PendingIntent pi(Context c,int id,int index){
  Intent in=new Intent(c,ReminderReceiver.class);in.putExtra("index",index);
  return PendingIntent.getBroadcast(c,id,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 private static int parseMinutes(String s,int def){
  try{String[] p=s.split(":");return Integer.parseInt(p[0].trim())*60+Integer.parseInt(p[1].trim());}catch(Exception e){return def;}
 }
 public static void schedule(Context c){
  AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  try{
   JSONObject d=new JSONObject(c.getSharedPreferences("puppy",0).getString("state","{}"));
   JSONObject r=d.optJSONObject("reminders");
   if(r==null||!r.optBoolean("enabled",false)){cancel(c);return;}
   int start=parseMinutes(r.optString("time","09:00"),540),end=parseMinutes(r.optString("end","22:00"),1320);
   int gap=Math.max(5,r.optInt("interval",60)),max=Math.min(30,Math.max(1,r.optInt("max",3)));
   for(int i=0;i<30;i++){
    PendingIntent p=pi(c,BASE+i,i);
    a.cancel(p);
    int m=start+i*gap;
    if(i>=max||m>end||m>=24*60)continue;
    Calendar t=Calendar.getInstance();t.set(Calendar.HOUR_OF_DAY,m/60);t.set(Calendar.MINUTE,m%60);t.set(Calendar.SECOND,0);t.set(Calendar.MILLISECOND,0);
    if(t.getTimeInMillis()<=System.currentTimeMillis()+1000)t.add(Calendar.DAY_OF_YEAR,1);
    set(c,a,t.getTimeInMillis(),p);
   }
   PendingIntent sp=pi(c,SNOOZE_ID,99);a.cancel(sp);
   long snooze=r.optLong("snoozeUntil",0);
   if(snooze>System.currentTimeMillis()+1000)set(c,a,snooze,sp);
  }catch(Exception ignored){}
 }
 static void cancel(Context c){
  AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  for(int i=0;i<30;i++)a.cancel(pi(c,BASE+i,i));
  a.cancel(pi(c,SNOOZE_ID,99));
 }
}
