package com.qinghe.puppy;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  ReminderReceiver.createChannel(c);
  Scheduler.schedule(c);
 }
}
