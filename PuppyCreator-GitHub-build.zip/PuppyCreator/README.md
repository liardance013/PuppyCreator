# 小狗创作助手 v1.0

Android 原生 Java 项目。功能：每日本地通知、通知测试、写作字数与绘画分钟打卡、最近7天统计、可更改提醒时间。默认09:00，使用手机本地时区（若手机设为北京时间即北京时间09:00）。

## 构建
1. 电脑安装 Android Studio（推荐新版稳定版，JDK 17）。
2. File → Open → 选择 PuppyCreator 文件夹。
3. 等待 Gradle 同步，安装 Android SDK 35（如提示）。
4. Build → Build APK(s)，生成 `app/build/outputs/apk/debug/app-debug.apk`。
5. 将 APK 传到 Android 手机安装。需要允许安装来自该来源的应用。

## 初次设置
打开 App，允许通知权限；如出现“允许精确提醒”按钮，点击并授权。可点“立即发送测试通知”验证通知是否能显示。部分品牌系统还需要允许后台运行、关闭严格省电限制。

## 限制
- 当前仅为源代码交付，未在真实设备上编译测试。
- Android 12+ 若未授予精确闹钟权限，会使用非精确闹钟，可能延迟。
- Android 系统省电和用户关闭通知可能导致提醒延迟或无法显示。
- 手机时区更改后将使用新的本地时区；目前未锁定北京时间。
- 数据保存在应用私有 SharedPreferences 中，卸载可能丢失。
- 当前无 AI 聊天、云同步、数据导出。

## 手机浏览器通过 GitHub Actions 构建 APK
1. 登录 GitHub，创建一个**私人**空仓库（不要勾选初始化 README）。
2. 上传本项目 `PuppyCreator` 文件夹**内部**的所有文件和目录（包括隐藏的 `.github` 目录）到仓库根目录。GitHub 网页上传可能不便上传隐藏目录；可在电脑或手机 Git 客户端中完成，或单独创建 `.github/workflows/build-apk.yml`。
3. 打开仓库的 Actions → Build Android APK → Run workflow，等待构建完成。
4. 点击本次构建结果中的 `PuppyCreator-debug-apk` 下载 ZIP，解压后得到 `app-debug.apk`，在安卓手机上安装。

提示：这是未经过真机验证的调试 APK 构建流程；构建失败时需要根据 Actions 日志修复。请勿将调试 APK 当作经过安全审核的正式发行版本。
