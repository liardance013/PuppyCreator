package com.qinghe.puppy;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView stats; EditText words,minutes; android.content.SharedPreferences prefs;
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA).format(new Date());}
    int dp(int n){return (int)(getResources().getDisplayMetrics().density*n);}
    TextView text(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.rgb(43,51,65));v.setPadding(0,dp(10),0,dp(10));return v;}
    Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    JSONObject records(){try{return new JSONObject(prefs.getString("records","{}"));}catch(Exception e){return new JSONObject();}}
    int val(JSONObject o,String k){return o.optInt(k,0);}
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("prefs",0);render();Scheduler.schedule(this);if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},1);}
    void render(){
        ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(22),dp(24),dp(22),dp(24));root.setBackgroundColor(Color.rgb(248,248,245));sc.addView(root);setContentView(sc);
        root.addView(text("小狗创作助手 🐕",27));root.addView(text("今天也要认真创作。先开始，再完善。",15));
        root.addView(text("今日打卡 · "+today(),20));
        JSONObject day=records().optJSONObject(today());if(day==null)day=new JSONObject();
        root.addView(text("写作字数",16));words=new EditText(this);words.setInputType(2);words.setHint("例如 300");words.setText(String.valueOf(val(day,"words")));root.addView(words);
        root.addView(text("绘画分钟数",16));minutes=new EditText(this);minutes.setInputType(2);minutes.setHint("例如 30");minutes.setText(String.valueOf(val(day,"minutes")));root.addView(minutes);
        Button save=button("保存今日打卡");root.addView(save);save.setOnClickListener(v->{try{int w=Integer.parseInt(words.getText().toString()),m=Integer.parseInt(minutes.getText().toString());if(w<0||m<0||w>1000000||m>1440)throw new Exception();JSONObject all=records(),entry=new JSONObject();entry.put("words",w);entry.put("minutes",m);all.put(today(),entry);prefs.edit().putString("records",all.toString()).apply();Toast.makeText(this,"打卡已保存！",Toast.LENGTH_SHORT).show();updateStats();}catch(Exception e){Toast.makeText(this,"请输入合理的非负数字",Toast.LENGTH_LONG).show();}});
        root.addView(text("创作统计",20));stats=text("",16);root.addView(stats);updateStats();
        int h=prefs.getInt("hour",9),m=prefs.getInt("minute",0);Button time=button(String.format(Locale.CHINA,"每日提醒时间：%02d:%02d",h,m));root.addView(time);time.setOnClickListener(v->new TimePickerDialog(this,(view,hh,mm)->{prefs.edit().putInt("hour",hh).putInt("minute",mm).apply();Scheduler.schedule(this);time.setText(String.format(Locale.CHINA,"每日提醒时间：%02d:%02d",hh,mm));},h,m,true).show());
        Button test=button("立即发送测试通知");root.addView(test);test.setOnClickListener(v->{new ReminderReceiver().onReceive(this,new Intent(this,ReminderReceiver.class));Toast.makeText(this,"已尝试发送测试通知，请检查通知权限",Toast.LENGTH_LONG).show();});
        if(Build.VERSION.SDK_INT>=31){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);if(!am.canScheduleExactAlarms()){Button permission=button("允许精确提醒（推荐）");root.addView(permission);permission.setOnClickListener(v->{try{startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,android.net.Uri.parse("package:"+getPackageName())));}catch(Exception e){Toast.makeText(this,"请在系统设置中开启闹钟与提醒权限",Toast.LENGTH_LONG).show();}});}}
        root.addView(text("说明：数据只保存在本机。通知可能受系统省电策略影响；开启通知、闹钟权限后效果更好。",13));
    }
    void updateStats(){JSONObject all=records();int w=0,m=0,days=0,completed=0;Calendar c=Calendar.getInstance();SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA);for(int i=0;i<7;i++){JSONObject d=all.optJSONObject(fmt.format(c.getTime()));if(d!=null){w+=val(d,"words");m+=val(d,"minutes");days++;if(val(d,"words")>=100&&val(d,"minutes")>=15)completed++;}c.add(Calendar.DAY_OF_YEAR,-1);}stats.setText("最近7天\n写作："+w+" 字\n绘画："+m+" 分钟\n打卡天数："+days+" 天\n双项达标："+completed+" 天");}
    @Override protected void onResume(){super.onResume();if(prefs!=null)Scheduler.schedule(this);}
}
